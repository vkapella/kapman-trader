"""Benchmark runner for the Wyckoff research harness."""

from .run_bench import run_bench

__all__ = ["run_bench"]
