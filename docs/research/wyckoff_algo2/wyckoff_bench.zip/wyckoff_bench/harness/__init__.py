# Harness components for Wyckoff research benchmark.
